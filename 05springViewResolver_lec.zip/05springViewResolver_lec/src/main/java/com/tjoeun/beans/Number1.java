package com.tjoeun.beans;

import lombok.Data;

@Data
public class Number1 {
  private int num1;
  private int num2;
  private int[] nums;
}
