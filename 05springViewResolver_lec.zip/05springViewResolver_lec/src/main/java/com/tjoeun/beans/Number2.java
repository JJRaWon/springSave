package com.tjoeun.beans;

import lombok.Data;

@Data
public class Number2 {
	private int num1;
  private int num2;
}
