package com.tjoeun.beans;

import lombok.Data;

@Data
public class CollegeStudent {
	private String memberNum;
  private String name;
  private String id;
  private String pw;
  private String phone;
  private String address;
}
