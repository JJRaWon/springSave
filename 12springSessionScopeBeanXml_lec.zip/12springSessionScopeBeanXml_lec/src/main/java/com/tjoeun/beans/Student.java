package com.tjoeun.beans;

import lombok.Data;

@Data
public class Student {
  private String studno;
  private String name;
  private String department;
}
