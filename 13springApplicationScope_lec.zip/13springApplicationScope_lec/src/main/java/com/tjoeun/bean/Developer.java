package com.tjoeun.bean;

import lombok.Data;

@Data
public class Developer {
  private String name;
  private int age;  
}
