package com.tjoeun.beans;

import lombok.Data;

@Data
public class Developer {
  private String name;
  private int age;
}
