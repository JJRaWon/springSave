package com.tjoeun.config;

import org.springframework.context.annotation.Configuration;

// project 작업할 때 생성하는 bean을 정의하는 클래스
@Configuration
public class RootAppContext {
	
	
	

}
