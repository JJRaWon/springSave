package com.tjoeun.beans;

import lombok.Data;

@Data
public class Student {
	private int number;
  private String name;
  private String id;
  private String pw;
  private String post;
}
