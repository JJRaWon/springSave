package com.tjoeun.beans;

import lombok.Data;

@Data
public class InfoClass {
  private String s1;
  private String s2;
  private String s3;
  private String s4;
  
  private String[] s5;
  private String[] s6;
  private String[] s7;
  private String[] s8;
  
  private String s9;
  private String s10;
  private String s11;
  private String s12;
}
