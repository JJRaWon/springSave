package com.tjoeun.beans;

import lombok.Data;

@Data
public class Developer {
	private String empno;
  private String ename;
  private int age;
}
